import 'package:flutter/material.dart';
import 'package:signup_fb/login.dart';



class InputClass extends StatefulWidget {
  const InputClass({super.key});

  @override
  State<InputClass> createState() => _InputClassState();
}

class _InputClassState extends State<InputClass> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: Padding(
          padding: const EdgeInsets.only(left: 170.0),
          child: Text('Sign-Up',style: TextStyle(fontSize: 30,fontWeight: FontWeight.bold),),
        ),
      ),

      body: Center(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 100.0),
               child:Container(
                margin: EdgeInsets.symmetric(horizontal: 70),
                decoration: BoxDecoration(
                  //color: Colors.purple,
                    border: Border.all(color: Colors.white),
                    borderRadius: BorderRadius.circular(10)
                ),
                  child: Padding(
                    padding: const EdgeInsets.only(left: 15.0),
                    child: TextFormField(
                      obscureText: true, // for hiding password only accept boolean data type
                      //obscuringCharacter: '.', // for password
                      style: TextStyle(color: Colors.white),// for input data by users
                      decoration: InputDecoration(
                          border: InputBorder.none,
                          hintText: 'Enter your First name',
                          hintStyle: TextStyle(color: Colors.white),
                        //
                          suffix: Padding(
                            padding: const EdgeInsets.only(right: 8.0),
                            child: Icon(Icons.person, color: Colors.white,),
                          )
                      ),
                    ),
                  ),
              ),
    ),
            //
            Padding(
              padding: const EdgeInsets.only(top: 20.0),
              child: Container(
                margin: EdgeInsets.symmetric(horizontal: 70),
                decoration: BoxDecoration(
                  //color: Colors.purple,
                    border: Border.all(color: Colors.white),
                    borderRadius: BorderRadius.circular(10)
                ),
                child: Padding(
                  padding: const EdgeInsets.only(left: 15.0),
                  child: TextFormField(
                    obscureText: true, // for hiding password only accept boolean data type
                    //obscuringCharacter: '.', // for password
                    style: TextStyle(color: Colors.white),// for input data by users
                    decoration: InputDecoration(
                        border: InputBorder.none,
                        hintText: 'Enter your Last name',
                        hintStyle: TextStyle(color: Colors.white),
                        //
                        suffix: Padding(
                          padding: const EdgeInsets.only(right: 8.0),
                          child: Icon(Icons.person, color: Colors.white,),
                        )
                    ),
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 20.0),
              child: Container(
                margin: EdgeInsets.symmetric(horizontal: 70),
                decoration: BoxDecoration(
                  //color: Colors.purple,
                    border: Border.all(color: Colors.white),
                    borderRadius: BorderRadius.circular(10)
                ),
                child: TextFormField(
                  obscureText: true, // for hiding password only accept boolean data type
                  //obscuringCharacter: '.', // for password
                  style: TextStyle(color: Colors.white),// for input data by users
                  decoration: InputDecoration(
                      border: InputBorder.none,
                      hintText: 'abc@gmail.com',
                      hintStyle: TextStyle(color: Colors.white),
                     // prefix: Padding(
                        //padding: const EdgeInsets.only(left: 15.0),
                        //child: Icon(Icons.mail_outline, color: Colors.white,),
                      //),
                      suffix: Padding(
                        padding: const EdgeInsets.only(right: 8.0),
                        child: Icon(Icons.mail_outline, color: Colors.white,),
                      )
                  ),
                ),

              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 20.0),
              child: Container(
                margin: EdgeInsets.symmetric(horizontal: 70),
                decoration: BoxDecoration(
                  //color: Colors.purple,
                    border: Border.all(color: Colors.white),
                    borderRadius: BorderRadius.circular(10)
                ),
                child: Padding(
                  padding: const EdgeInsets.only(left: 15.0),
                  child: TextFormField(
                    obscureText: true, // for hiding password only accept boolean data type
                    obscuringCharacter: '.', // for password
                    style: TextStyle(color: Colors.white),// for input data by users
                    decoration: InputDecoration(
                        border: InputBorder.none,
                        hintText: 'Enter your password',
                        hintStyle: TextStyle(color: Colors.white),
                        suffix: Padding(
                          padding: const EdgeInsets.only(right: 8.0),
                          child: Icon(Icons.remove_red_eye_outlined, color: Colors.white,),
                        )
                    ),
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(top: 30.0),
              child: Container(
                margin: EdgeInsets.symmetric(horizontal: 70),
                decoration: BoxDecoration(
                  //color: Colors.purple,
                    border: Border.all(color: Colors.white),
                    borderRadius: BorderRadius.circular(10)
                ),
                child: Padding(
                  padding: const EdgeInsets.only(left:15.0),
                  child: TextFormField(
                    obscureText: true, // for hiding password only accept boolean data type
                    //obscuringCharacter: '.', // for password
                    style: TextStyle(color: Colors.white),// for input data by users
                    decoration: InputDecoration(
                        border: InputBorder.none,
                        hintText: 'Confirm Password',
                        hintStyle: TextStyle(color: Colors.white),
                        //
                        suffix: Padding(
                          padding: const EdgeInsets.only(right: 8.0),
                          child: Icon(Icons.remove_red_eye, color: Colors.white,),
                        )
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(height: 20,),
            TextButton(
              style: TextButton.styleFrom(
                backgroundColor: Colors.white,
                padding: const EdgeInsets.all(12),
              ),
              child: const Text('Sign-Up'),
              onPressed: () {
                Navigator.push(context, MaterialPageRoute(builder: (context)=>Login()));
              },
            ),
          ],
        ),


      ),
    );
  }
}
